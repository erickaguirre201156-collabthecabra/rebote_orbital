extends Area2D

signal reached
var locked := false

func _ready() -> void:
	body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node2D) -> void:
	if body is CharacterBody2D and not locked:
		reached.emit()

func set_locked(value: bool) -> void:
	locked = value
	$LockIcon.visible = locked
	$Sprite2D.modulate = Color(0.6, 0.7, 0.8) if locked else Color.WHITE
