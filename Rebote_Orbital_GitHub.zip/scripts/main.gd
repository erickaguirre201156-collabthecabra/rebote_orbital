extends Node2D

const LEVELS = [preload("res://scenes/level_1.tscn"), preload("res://scenes/level_2.tscn"), preload("res://scenes/level_3.tscn"), preload("res://scenes/level_4.tscn"), preload("res://scenes/level_5.tscn"), preload("res://scenes/level_6.tscn"), preload("res://scenes/level_7.tscn")]
const SPRING = preload("res://scenes/spring.tscn")
const ARCADE_ROOM = preload("res://scenes/arcade_room.tscn")
const ALIEN_ARCADE = preload("res://scenes/alien_arcade.tscn")
const COIN_SOUND = preload("res://assets/audio/moneda.wav")
const JUMP_SOUND = preload("res://assets/audio/salto.wav")
const DEATH_SOUND = preload("res://assets/audio/muerte.wav")
const WIN_SOUND = preload("res://assets/audio/victoria.wav")
const MUSIC = preload("res://assets/audio/fondo.wav")
const EXPLOSION_SOUND = preload("res://assets/audio/explosion.wav")
const TIME_LIMIT := 123.0
var level_index := 0
var level: Node2D
var player: CharacterBody2D
var dynamic_springs: Array[Node2D] = []
var coins := 0
var falls := 0
var lives := 3
var game_over := false
var in_room := false
var in_arcade := false
var time_remaining := TIME_LIMIT
var timer_stopped := false
var menu_open := true
var finished := false
var transitioning := false
var boss_defeated := false
var coin_audio: AudioStreamPlayer
var jump_audio: AudioStreamPlayer
var death_audio: AudioStreamPlayer
var win_audio: AudioStreamPlayer
var lives_label: Label
var timer_label: Label
var music_audio: AudioStreamPlayer
var explosion_audio: AudioStreamPlayer
var explosion_overlay: ColorRect
var explosion_message: Label
var menu_layer: ColorRect
@onready var hud: Label = $CanvasLayer/HUD
@onready var help: Label = $CanvasLayer/Help

func _ready() -> void:
	coin_audio = _make_audio(COIN_SOUND)
	jump_audio = _make_audio(JUMP_SOUND)
	death_audio = _make_audio(DEATH_SOUND)
	win_audio = _make_audio(WIN_SOUND)
	music_audio = _make_audio(MUSIC)
	music_audio.volume_db = -20.0
	music_audio.finished.connect(_on_music_finished)
	explosion_audio = _make_audio(EXPLOSION_SOUND)
	lives_label = Label.new()
	lives_label.position = Vector2(755, 5)
	lives_label.add_theme_font_size_override("font_size", 22)
	lives_label.add_theme_color_override("font_color", Color(0.82, 0.15, 0.22))
	$CanvasLayer.add_child(lives_label)
	timer_label = Label.new()
	timer_label.position = Vector2(795, 69)
	timer_label.add_theme_font_size_override("font_size", 24)
	timer_label.add_theme_color_override("font_color", Color(0.8, 0.12, 0.1))
	$CanvasLayer.add_child(timer_label)
	explosion_overlay = ColorRect.new()
	explosion_overlay.size = Vector2(960, 540)
	explosion_overlay.color = Color(1.0, 0.2, 0.02, 0.0)
	explosion_overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	explosion_overlay.visible = false
	$CanvasLayer.add_child(explosion_overlay)
	explosion_message = Label.new()
	explosion_message.position = Vector2(225, 220)
	explosion_message.add_theme_font_size_override("font_size", 42)
	explosion_message.add_theme_color_override("font_color", Color.WHITE)
	explosion_message.visible = false
	$CanvasLayer.add_child(explosion_message)
	menu_layer = ColorRect.new()
	menu_layer.size = Vector2(960, 540)
	menu_layer.color = Color(0.04, 0.08, 0.19, 0.88)
	$CanvasLayer.add_child(menu_layer)
	var title := Label.new()
	title.text = "RE BOTE ORBITAL"
	title.position = Vector2(270, 135)
	title.add_theme_font_size_override("font_size", 48)
	title.add_theme_color_override("font_color", Color(0.9, 0.97, 1))
	menu_layer.add_child(title)
	var subtitle := Label.new()
	subtitle.text = "Ayuda a George a vencer a la jefa y jugar en el arcade"
	subtitle.position = Vector2(185, 225)
	subtitle.add_theme_font_size_override("font_size", 22)
	menu_layer.add_child(subtitle)
	var play_button := Button.new()
	play_button.text = "JUGAR"
	play_button.position = Vector2(370, 310)
	play_button.size = Vector2(220, 65)
	play_button.add_theme_font_size_override("font_size", 30)
	play_button.pressed.connect(start_game)
	menu_layer.add_child(play_button)
	level = self
	setup_level(0)
	show_menu()

func show_menu() -> void:
	menu_open = true
	menu_layer.visible = true
	music_audio.stop()
	if is_instance_valid(player):
		player.set_physics_process(false)

func start_game() -> void:
	if not menu_open:
		return
	menu_open = false
	menu_layer.visible = false
	time_remaining = TIME_LIMIT
	timer_stopped = false
	update_timer()
	if is_instance_valid(player):
		player.set_physics_process(true)
	music_audio.play()

func _process(delta: float) -> void:
	if finished or game_over or timer_stopped or menu_open:
		return
	time_remaining = maxf(0.0, time_remaining - delta)
	update_timer()
	if time_remaining <= 0.0:
		explode()

func update_timer() -> void:
	var minutes := floori(time_remaining / 60.0)
	var seconds := floori(fmod(time_remaining, 60.0))
	var hundredths := floori(fmod(time_remaining, 1.0) * 100.0)
	timer_label.text = "%d:%02d.%02d" % [minutes, seconds, hundredths]

func _on_music_finished() -> void:
	if not finished and not game_over:
		music_audio.play()

func explode() -> void:
	game_over = true
	music_audio.stop()
	explosion_audio.play()
	if is_instance_valid(player):
		player.set_physics_process(false)
	if level_index == 6 and not in_arcade and not in_room:
		var boss = level.get_node_or_null("PeppaPigBoss")
		if boss:
			boss.set_physics_process(false)
	for fireball in get_tree().get_nodes_in_group("boss_fireballs"):
		fireball.queue_free()
	explosion_overlay.visible = true
	explosion_overlay.color = Color(1.0, 0.25, 0.02, 0.9)
	create_tween().tween_property(explosion_overlay, "color", Color(0.55, 0.05, 0.02, 0.7), 0.8)
	explosion_message.text = "¡BOOM! Tiempo agotado\n Pulsa R para reiniciar"
	explosion_message.visible = true

func _make_audio(sound: AudioStream) -> AudioStreamPlayer:
	var audio := AudioStreamPlayer.new()
	audio.stream = sound
	audio.volume_db = -7.0
	$CanvasLayer.add_child(audio)
	return audio

func _unhandled_key_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_R:
			finished = false
			game_over = false
			time_remaining = TIME_LIMIT
			timer_stopped = false
			explosion_overlay.visible = false
			explosion_message.visible = false
			lives = 3
			falls = 0
			load_level(0)
			show_menu()
		elif finished and event.keycode == KEY_ENTER:
			finished = false
			time_remaining = TIME_LIMIT
			timer_stopped = false
			lives = 3
			falls = 0
			load_level(0)
			show_menu()

func load_level(index: int) -> void:
	transitioning = false
	game_over = false
	in_room = false
	in_arcade = false
	if level == self:
		for child in get_children():
			if child != $CanvasLayer:
				remove_child(child)
				child.queue_free()
	elif is_instance_valid(level):
		remove_child(level)
		level.queue_free()
	level = LEVELS[index].instantiate()
	add_child(level)
	move_child(level, 0)
	setup_level(index)

func load_room() -> void:
	transitioning = false
	timer_stopped = true
	in_room = true
	in_arcade = false
	remove_child(level)
	level.queue_free()
	level = ARCADE_ROOM.instantiate()
	add_child(level)
	move_child(level, 0)
	player = level.get_node("Player")
	player.fell.connect(_on_player_fell)
	player.jumped.connect(func() -> void: jump_audio.play())
	level.started.connect(load_arcade)
	hud.text = "SALA ARCADE     Monedas: %d" % coins
	help.text = "Acércate a la máquina y pulsa E"

func load_arcade() -> void:
	in_room = false
	in_arcade = true
	remove_child(level)
	level.queue_free()
	level = ALIEN_ARCADE.instantiate()
	add_child(level)
	move_child(level, 0)
	player = null
	level.hit.connect(_on_arcade_hit)
	level.won.connect(_on_arcade_won)
	hud.text = "AVIÓN CONTRA ALIENÍGENAS     Enemigos: 8"
	help.text = "A/D o flechas: mover     Espacio: disparar"

func _on_arcade_hit() -> void:
	if game_over or finished:
		return
	lives -= 1
	death_audio.play()
	lives_label.text = "George: " + "♥".repeat(lives)
	if lives <= 0:
		game_over = true
		level.set_process(false)
		hud.text = "GAME OVER     Derribaron el avión"
		help.text = "Pulsa R para empezar de nuevo"

func _on_arcade_won() -> void:
	if game_over or finished:
		return
	finished = true
	music_audio.stop()
	win_audio.play()
	hud.text = "¡GANASTE! George venció a los alienígenas"
	help.text = "Pulsa ENTER para jugar otra vez"

func setup_level(index: int) -> void:
	level_index = index
	boss_defeated = false
	dynamic_springs.clear()
	coins = 0
	player = level.get_node("Player")
	player.fell.connect(_on_player_fell)
	player.jumped.connect(func() -> void: jump_audio.play())
	var goal = level.get_node("Goal")
	goal.reached.connect(_on_goal_reached)
	if index == 6:
		goal.set_locked(true)
		level.get_node("PeppaPigBoss").defeated.connect(_on_boss_defeated)
	for coin in get_tree().get_nodes_in_group("coins"):
		if level.is_ancestor_of(coin):
			coin.picked_up.connect(_on_coin_picked_up)
	refresh_hud()
	update_timer()

func refresh_hud() -> void:
	hud.text = "RE BOTE ORBITAL     Nivel %d/7     Monedas: %d     Caidas: %d" % [level_index + 1, coins, falls]
	lives_label.text = "George: " + "♥".repeat(lives)
	help.text = "A/D o flechas: mover     Espacio: saltar     R: reiniciar     Llega a la bandera"
	if level_index == 6 and not boss_defeated and not in_room and not in_arcade:
		help.text = "Jefa Peppa Pig: rebota sobre ella 3 veces; luego ve a la bandera"

func _on_coin_picked_up() -> void:
	coins += 1
	coin_audio.play()
	refresh_hud()

func _on_player_fell(at: Vector2) -> void:
	death_audio.play()
	_handle_fall.call_deferred(at)

func _handle_fall(at: Vector2) -> void:
	if transitioning or finished or game_over:
		return
	falls += 1
	lives -= 1
	if lives <= 0:
		game_over = true
		if is_instance_valid(player):
			player.set_physics_process(false)
		if level_index == 6 and not in_room:
			var boss = level.get_node_or_null("PeppaPigBoss")
			if boss:
				boss.set_physics_process(false)
		for fireball in get_tree().get_nodes_in_group("boss_fireballs"):
			fireball.queue_free()
		refresh_hud()
		hud.text = "GAME OVER     George se quedó sin vidas"
		help.text = "Pulsa R para empezar de nuevo"
		return
	if dynamic_springs.size() >= 3:
		var oldest: Node2D = dynamic_springs.pop_front()
		oldest.queue_free()
	if not in_room:
		var pad: Node2D = SPRING.instantiate()
		pad.position = at
		level.add_child(pad)
		dynamic_springs.append(pad)
	for fireball in get_tree().get_nodes_in_group("boss_fireballs"):
		fireball.queue_free()
	player.respawn()
	refresh_hud()

func _on_goal_reached() -> void:
	if transitioning or finished or game_over:
		return
	if level_index == 6 and not boss_defeated:
		return
	if level_index == 6:
		timer_stopped = true
	transitioning = true
	_advance_level.call_deferred()

func _advance_level() -> void:
	if level_index < LEVELS.size() - 1:
		load_level(level_index + 1)
	else:
		load_room()

func _on_boss_defeated() -> void:
	boss_defeated = true
	level.get_node("Goal").set_locked(false)
	refresh_hud()
	help.text = "¡Jefa vencida! Ahora ve a la bandera"
