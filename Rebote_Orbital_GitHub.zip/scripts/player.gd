extends CharacterBody2D

signal fell(at: Vector2)
signal jumped

const SPEED := 300.0
const JUMP := -490.0
const GRAVITY := 1200.0
var spawn_position := Vector2.ZERO
var last_safe := Vector2.ZERO
var dying := false
var jump_held := false

func _ready() -> void:
	spawn_position = position
	last_safe = position
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST

func _physics_process(delta: float) -> void:
	var direction := int(Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT)) - int(Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT))
	velocity.x = move_toward(velocity.x, direction * SPEED, 1700.0 * delta)
	var jump_pressed := Input.is_key_pressed(KEY_SPACE) or Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP)
	if is_on_floor() and jump_pressed and not jump_held:
		velocity.y = JUMP
		jumped.emit()
	jump_held = jump_pressed
	velocity.y = minf(velocity.y + GRAVITY * delta, 1000.0)
	move_and_slide()
	position.x = clampf(position.x, 15.0, 945.0)
	if is_on_floor():
		last_safe = position
	if position.y > 570.0:
		die()

func bounce() -> void:
	if velocity.y >= -100.0:
		velocity.y = -770.0

func die() -> void:
	if dying:
		return
	dying = true
	fell.emit(last_safe + Vector2(0, 15))

func respawn() -> void:
	position = spawn_position
	velocity = Vector2.ZERO
	jump_held = false
	dying = false
