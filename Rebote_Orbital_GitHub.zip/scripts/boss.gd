extends Area2D

signal defeated

const FIREBALL = preload("res://scenes/fireball.tscn")
const FIRE_INTERVAL := 2.0

@export var left_limit := 680.0
@export var right_limit := 820.0
var lives := 3
var direction := -1.0
var invincible := 0.0
var fire_timer := 0.0

func _ready() -> void:
	body_entered.connect(_on_body_entered)

func _physics_process(delta: float) -> void:
	if lives <= 0:
		return
	fire_timer += delta
	if fire_timer >= FIRE_INTERVAL:
		fire_timer -= FIRE_INTERVAL
		shoot_fireball()
	position.x += direction * 65.0 * delta
	if position.x <= left_limit:
		direction = 1.0
	elif position.x >= right_limit:
		direction = -1.0
	invincible = maxf(0.0, invincible - delta)
	$Sprite2D.visible = invincible <= 0.0 or Engine.get_physics_frames() % 6 < 3
	$Heart1.visible = lives >= 1
	$Heart2.visible = lives >= 2
	$Heart3.visible = lives >= 3

func shoot_fireball() -> void:
	var target: Node2D = get_parent().get_node("Player")
	var fireball: Area2D = FIREBALL.instantiate()
	fireball.position = position + Vector2(-30, -8)
	fireball.set("direction", (target.position - fireball.position).normalized())
	get_parent().add_child(fireball)

func _on_body_entered(body: Node2D) -> void:
	if lives <= 0 or invincible > 0.0:
		return
	if body is CharacterBody2D:
		if body.velocity.y > 0.0 and body.global_position.y < global_position.y - 8.0:
			lives -= 1
			invincible = 0.8
			body.bounce()
			if lives <= 0:
				for fireball in get_tree().get_nodes_in_group("boss_fireballs"):
					fireball.queue_free()
				defeated.emit()
				queue_free()
		else:
			body.die()
