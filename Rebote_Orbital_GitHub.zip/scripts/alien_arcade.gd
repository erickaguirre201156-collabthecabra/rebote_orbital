extends Node2D

signal hit
signal won

const PLANE_SPEED := 360.0
const SHOT_SPEED := 620.0
const ALIEN_SHOT_SPEED := 220.0

var plane_x := 480.0
var aliens: Array[Vector2] = []
var shots: Array[Vector2] = []
var alien_shots: Array[Dictionary] = []
var elapsed := 0.0
var shoot_timer := 0.0
var alien_timer := 0.0
var invincible := 0.0

func _ready() -> void:
	for row in range(2):
		for col in range(4):
			aliens.append(Vector2(235 + col * 165, 115 + row * 85))

func _process(delta: float) -> void:
	elapsed += delta
	shoot_timer = maxf(0.0, shoot_timer - delta)
	invincible = maxf(0.0, invincible - delta)
	var movement := int(Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT)) - int(Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT))
	plane_x = clampf(plane_x + movement * PLANE_SPEED * delta, 30.0, 930.0)
	if Input.is_key_pressed(KEY_SPACE) and shoot_timer <= 0.0:
		shots.append(Vector2(plane_x, 433))
		shoot_timer = 0.22
	for i in range(shots.size() - 1, -1, -1):
		shots[i].y -= SHOT_SPEED * delta
		if shots[i].y < 0.0:
			shots.remove_at(i)
			continue
		for j in range(aliens.size() - 1, -1, -1):
			if shots[i].distance_to(alien_position(aliens[j])) < 26.0:
				aliens.remove_at(j)
				shots.remove_at(i)
				if aliens.is_empty():
					set_process(false)
					won.emit()
				break
	alien_timer += delta
	if alien_timer >= 1.2 and not aliens.is_empty():
		alien_timer -= 1.2
		var source := alien_position(aliens[randi() % aliens.size()])
		var target := Vector2(plane_x, 455)
		alien_shots.append({"pos": source, "vel": (target - source).normalized() * ALIEN_SHOT_SPEED})
	for i in range(alien_shots.size() - 1, -1, -1):
		var bullet: Dictionary = alien_shots[i]
		bullet["pos"] += bullet["vel"] * delta
		alien_shots[i] = bullet
		if bullet["pos"].y > 545.0:
			alien_shots.remove_at(i)
		elif invincible <= 0.0 and bullet["pos"].distance_to(Vector2(plane_x, 455)) < 20.0:
			alien_shots.remove_at(i)
			invincible = 1.1
			hit.emit()
	queue_redraw()

func alien_position(base: Vector2) -> Vector2:
	return base + Vector2(sin(elapsed * 1.4) * 38.0, 0)

func _draw() -> void:
	draw_rect(Rect2(0, 0, 960, 540), Color(0.025, 0.035, 0.11))
	for i in range(32):
		var x := float((i * 173 + 51) % 960)
		var y := float((i * 97 + 29) % 530)
		draw_circle(Vector2(x, y), 1.5, Color(0.7, 0.8, 1))
	for base in aliens:
		var p := alien_position(base)
		draw_circle(p, 22, Color(0.2, 0.95, 0.45))
		draw_rect(Rect2(p.x - 13, p.y - 5, 7, 7), Color(0.02, 0.1, 0.09))
		draw_rect(Rect2(p.x + 6, p.y - 5, 7, 7), Color(0.02, 0.1, 0.09))
	for shot in shots:
		draw_rect(Rect2(shot.x - 3, shot.y - 12, 6, 18), Color(0.35, 0.9, 1))
	for bullet in alien_shots:
		draw_circle(bullet["pos"], 9, Color(1, 0.3, 0.08))
	if invincible <= 0.0 or Engine.get_process_frames() % 8 < 4:
		draw_colored_polygon(PackedVector2Array([Vector2(plane_x, 425), Vector2(plane_x - 27, 475), Vector2(plane_x, 462), Vector2(plane_x + 27, 475)]), Color(0.25, 0.75, 1))
		draw_circle(Vector2(plane_x, 453), 7, Color(1, 0.9, 0.3))
