extends Area2D

const SPEED := 250.0
var direction := Vector2.LEFT

func _ready() -> void:
	add_to_group("boss_fireballs")
	body_entered.connect(_on_body_entered)
	queue_redraw()

func _physics_process(delta: float) -> void:
	position += direction * SPEED * delta
	if position.x < -30.0 or position.x > 990.0 or position.y < -30.0 or position.y > 590.0:
		queue_free()

func _draw() -> void:
	draw_circle(Vector2.ZERO, 13.0, Color(1.0, 0.25, 0.04))
	draw_circle(Vector2(-3, -3), 8.0, Color(1.0, 0.67, 0.08))
	draw_circle(Vector2(-5, -5), 3.0, Color(1.0, 0.95, 0.4))

func _on_body_entered(body: Node2D) -> void:
	if body.has_method("die"):
		body.die()
		queue_free()
