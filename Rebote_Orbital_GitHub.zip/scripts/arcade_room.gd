extends Node2D

signal started

@onready var player: CharacterBody2D = $Player
var prompt: Label
var e_held := false

func _ready() -> void:
	prompt = Label.new()
	prompt.position = Vector2(650, 300)
	prompt.add_theme_font_size_override("font_size", 22)
	prompt.add_theme_color_override("font_color", Color(1, 0.95, 0.35))
	add_child(prompt)

func _process(_delta: float) -> void:
	var near_machine := absf(player.position.x - 790.0) < 105.0
	prompt.text = "Pulsa E para jugar" if near_machine else "Acércate a la máquina"
	var e_pressed := Input.is_key_pressed(KEY_E)
	if near_machine and e_pressed and not e_held:
		started.emit()
		set_process(false)
	e_held = e_pressed

func _draw() -> void:
	draw_rect(Rect2(0, 0, 960, 540), Color(0.13, 0.12, 0.24))
	for x in range(0, 960, 80):
		draw_line(Vector2(x, 0), Vector2(x, 470), Color(0.2, 0.18, 0.32), 2)
	draw_rect(Rect2(0, 470, 960, 70), Color(0.38, 0.32, 0.42))
	draw_rect(Rect2(700, 212, 180, 258), Color(0.16, 0.08, 0.28))
	draw_rect(Rect2(719, 235, 142, 130), Color(0.02, 0.05, 0.16))
	draw_rect(Rect2(730, 247, 120, 100), Color(0.07, 0.21, 0.38))
	draw_colored_polygon(PackedVector2Array([Vector2(790, 270), Vector2(773, 318), Vector2(807, 318)]), Color(0.3, 0.9, 1))
	draw_circle(Vector2(790, 395), 11, Color(1, 0.25, 0.2))
	draw_rect(Rect2(705, 455, 170, 15), Color(0.8, 0.2, 0.6))
