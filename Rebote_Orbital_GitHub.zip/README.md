# Rebote Orbital

Proyecto de Godot 4 con **siete niveles y escenas editables**. Tu cerdito es el personaje y la plataforma azul es el trampolín. El último nivel tiene una jefa cerdita llamada Peppa Pig.

## Abrir

1. Descomprime el ZIP.
2. Abre Godot 4 y pulsa **Importar**.
3. Selecciona `project.godot`.
4. Pulsa **F5** para jugar.

## Escenas que puedes cambiar

- `scenes/level_1.tscn` a `level_7.tscn`: los siete niveles. Selecciona y mueve plataformas, monedas, trampolines, pinchos y bandera.
- `scenes/player.tscn`: tu cerdito y su colisión.
- `scenes/spring.tscn`: la plataforma azul de salto.
- `scenes/platform.tscn`, `coin.tscn`, `spike.tscn`, `goal.tscn`: los demás objetos.
- `scenes/boss.tscn`: la jefa del último nivel.
- `scenes/main.tscn`: la escena principal. **El primer nivel y todos sus objetos están directamente en el árbol de esta escena.**

Los PNG del cerdito, plataforma azul, moneda, pinchos, bandera, suelo, planeta, estrellas, jefa y corazones están en `assets/`. Los scripts están en `scripts/`.

## Cómo se juega

- A/D o flechas: moverse.
- Espacio, W o flecha arriba: saltar.
- R: reiniciar el nivel.

Al caer, se crea otra plataforma azul donde estuviste sobre suelo firme. Puedes dejar tres. Llega a la bandera para pasar al siguiente nivel. Las monedas son opcionales. En el nivel 7, rebota sobre la jefa tres veces antes de ir a la bandera. Sus tres corazones muestran los golpes que faltan.
